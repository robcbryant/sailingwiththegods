﻿using UnityEngine;
using System.Collections;

public class script_WaterWindCurrentVector : MonoBehaviour {


	Material thisMaterial;
	public float currentMagnitude = 3f; //in km/h
	// Use this for initialization
	void Start () {

	}

}
